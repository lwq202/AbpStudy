﻿namespace Study
{
    public class StudyConsts
    {
        public const string LocalizationSourceName = "Study";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
